
const Head = () => {
  return (
    <div>Head</div>
  )
}

export default Head
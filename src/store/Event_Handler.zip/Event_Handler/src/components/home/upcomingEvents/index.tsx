
const UpcomingEvents = () => {
  return (
    <div>UpcomingEvents</div>
  )
}

export default UpcomingEvents
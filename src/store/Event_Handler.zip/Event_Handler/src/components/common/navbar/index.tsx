
const Navbar = () => {
  return (
    <div>Navbar</div>
  )
}

export default Navbar